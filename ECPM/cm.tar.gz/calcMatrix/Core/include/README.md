# header file for analysis

## class

- Vector
- Matrix
- Tensor
- Getopt
- Range
- Slice
- GmxHandle
