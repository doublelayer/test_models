#include "zlib.h"

void test_zlib(void)
{
    zlibVersion();
}
